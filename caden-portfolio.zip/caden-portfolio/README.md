# Caden Terrell: Portfolio reference

This is a plain HTML, CSS, and JavaScript implementation of the supplied wireframe. Open `dist/index.html` in a browser to view it locally. No dependencies or build step are required.

- `dist/index.html`: page structure, project order, navigation, and contact links.
- `dist/styles.css`: shared colors, desktop layout, and mobile breakpoints.
- `dist/script.js`: project details and accessible native dialog behavior.
- `dist/assets/`: supplied artwork, portrait, original wireframe, and favicon.

The supplied wireframe is used as the portfolio project's process image. MTOTO uses a text cover and is explicitly labeled work in progress. Replace either with your own project cover when ready. Runnerworld, Coca-Cola, and Friendly link directly to their supplied Behance case studies in new tabs. Portfolio and MTOTO buttons show short project summaries. The footer Behance link points to your profile.

To study the implementation, start with the HTML, then follow the matching class names in the CSS. Desktop project rows use CSS Grid; below 580px they become a single column. The portrait sits beside the introduction on desktop and below it on phones.
